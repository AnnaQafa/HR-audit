# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError, AccessError
from datetime import datetime
from dateutil import relativedelta


class menaxh_aktiv(models.Model):
    _inherit = 'hr.employee'
    _description = "Menaxhim aktiviteti"

    #em_aktiv_id = fields.Many2one('aktivitete.aktivitete', string="Aktiviteti")
    name = fields.Char(string="Punonjes")
    objektiva_ids = fields.Many2many('objektivat.objektivat', string="Objektivat")
    vlersim_perf_ids = fields.One2many('vleresim_perf.vleresim_perf', 'emer_punonj_id', string="Vleresim")

class Objektivat(models.Model):
    _name = "objektivat.objektivat"
    _description = "Objektivi per secilin punonjes"

    name = fields.Char(string="Objektivi", required=True)
    dt_fillimi = fields.Date( string="Data e fillimit", default=datetime.now().strftime('%Y-%m-01'))
    # duration = fields.Char('Kohezgjatja', required=True)
    afati_perf = fields.Date(string="Afati i perfundimit", default=str(datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=-1))[:10])
    info_objektiv = fields.Text(string="Informacion shtese per objektivin")
    punonjes_ids = fields.Many2many('hr.employee', string="Punonjesit")
    #emr_aktivit = fields.Char(string="Emri i aktivitetit")
    aktivitet_id = fields.Many2one('aktivitete.aktivitete', string="Aktiviteti")
    statusi = fields.Selection([('1', 'Draft'), ('2', 'Running'), ('3', 'Done')], string="Statusi")
    vl_pik_ids = fields.One2many('pike_obj.pike_obj', 'objektiv_id', string="Vleresimi ne pike")
    arritshmeria_obj = fields.Float(compute="_get_avg_points_obj", string="Arritshmeria e objektivit")
    # arritshmeria_tot = fields.Float(compute="_get_avg_total", string="Arritshmeria e objektivave")


    @api.multi
    def _get_avg_points_obj(self):
        for objektiv in self:
            pike = 0.0
            avg = 0.0
            if objektiv.vl_pik_ids:
                for objektiv_pike in objektiv.vl_pik_ids:
                    pike += objektiv_pike.pike
                avg = pike / len(objektiv.vl_pik_ids.ids)


            objektiv.arritshmeria_obj = avg

    # @api.multi
    # def _get_avg_total(self):
    #     for record in self:
    #         shum_mes = 0.0
    #         avg_total = 0.0
    #






            # if objektivat.arritshmeria_obj:
            #     for objektivat_tot in objektivat.arritshmeria_obj:
            #       pike_tot += objektivat_tot.pike_tot
            #     avg_total = pike_tot / len(objektivat.arritshmeria_obj)
            #
            # objektivat.arritshmeria_total = avg_total

        # if objektivat.arritshmeria_obj:
        #         for objektivat_tot in objektivat.arritshmeria_obj:




    _sql_constraints = [
        ('objektiv_unik', 'unique(name)', "Nuk mund t'i caktohet i njejti objektiv te njejtit punonjes"),
    ]

    @api.constrains('punonjes_ids', 'statusi')
    def _check_status(self):
        for punonj in self:
            if not(punonj.punonjes_ids) and punonj.statusi == '2':
                raise ValidationError(_('Ju nuk mund te kaloni ne statusin Running pa vendosur punonjes'))






class Aktivitete(models.Model):
    _name = "aktivitete.aktivitete"
    _description = "Aktivitetet"

    name = fields.Char(string="Aktitviteti")


class Pike_obj(models.Model):
    _name = 'pike_obj.pike_obj'
    _description = "Piket bazuar ne objektivat"

    punonjesi_id = fields.Many2one('hr.employee', related='vleresim_perform_id.emer_punonj_id', string="Punonjesi")
    vleresim_perform_id = fields.Many2one('vleresim_perf.vleresim_perf', string="Vleresim")
    objektiv_id = fields.Many2one('objektivat.objektivat', string="Objektivi")
    # name_aktiv_id = fields.Many2one('aktivitete.aktivitete', string="Aktiviteti")
    pike = fields.Float(string="Piket")

    # _sql_constraints = [
    #    ('name_uniq', 'unique (punonjesi_id,objektiv_id)', "Tag name already exists !"),
    # ]

    @api.model
    def create(self, vals):
        if vals.get('punonjesi_id',False)  and vals.get('objektiv_id',False):
            ids = self.search(['&',('punonjesi_id','=',vals['punonjesi_id']),('objektiv_id','=',vals['objektiv_id'])])
            if ids:
                raise ValidationError(_('Nuk mund te caktohet i njejti objektiv te njejtit punoonjes' ))

        return super(Pike_obj, self).create(vals)

    @api.multi
    def write(self, vals):
        if 'punonjesi_id' in vals:
            existing_punonj_objektiv = self.search(['&',('punonjesi_id', 'in', self.mapped('punonjesi_id').ids),('objektiv_id', '!=', self.mapped('objektiv_id').ids)])
            if existing_punonj_objektiv:
                raise ValidationError(_("You can not change the"))


        # if 'punonjesi_id' in vals:
        #     existing_objektiv = self.search([
        #
        #         ('punonjesi_id', 'in', self.mapped('punonjesi_id').ids),
        #         ('objektiv_id', self.mapped('objektiv_id').ids),
        #     ])
        #     if existing_objektiv:
        #         raise ValidationError(_("You can not "))
        # if 'objektiv_id' in vals:
        #     existing_punonj = self.search([
        #
        #         ('objektiv_id', 'in', self.mapped('objektiv_id').ids),
        #     ])
        #     if existing_punonj:
        #         raise ValidationError(_("You can not change the punonj"))

        return super(Pike_obj, self).write(vals)


    # arritshmeria_total = fields.Float(compute="_get_avg_total", string="Arritshmeria e objektivave")
    #
    # @api.multi
    # def _get_avg_total(self):
    #     for objektivat in self:
    #
    #         if objektivat.objektiv_id:
    #             for objektivat_tot in objektivat.objektiv_id:
    #                 arritshmeria_obj = objektivat.objektiv_id.arritshmeria_obj
    #
    #             avg_tot = arritshmeria_obj / len(objektivat.objektiv_id)
    #         # if objektivat.objektiv_id:
    #         #     for objektivat_tot in objektivat.objektiv_id:
    #         #         arritshmeria_obj += objektivat_tot.arritshmeria_obj
    #         #     avg_tot = arritshmeria_obj / len(objektivat.objektiv_id)
    #         objektivat.arritshmeria_total = avg_tot

    @api.constrains('pike')
    def _check_pike(self):
        if self.pike < 0 or self.pike > 100:
                raise ValidationError(_('Kufiri i pikeve qe mund te vendosni eshte midis 0 dhe 100'))
        #if self.search_count([('','=',)])


    # _sql_constraints = [
    #     ('emer_objekt_unik', 'unique(punonjesi_id, vleresim_perform_id, objektiv_id)',
    #      'Nuk i caktohet i njejti oobjektiv te njejtit punonjes'),
    # ]


class Vleresim_perf(models.Model):
    _name = "vleresim_perf.vleresim_perf"
    _description = "Vleresimi i performances se secilit punonjes"

    emer_punonj_id = fields.Many2one('hr.employee', string="Emri i punonjesit")
    data_vleresim = fields.Datetime(string="Data e vleresimit")
    # vleresim_ids = fields.Many2many('objektivat.objektivat', string="Vleresimiiii")
    # name = fields.Char(string="Vleresim performance")
    name = fields.Char(string="Periudha e vleresimit")
    performanc_ids = fields.One2many('pike_obj.pike_obj', 'vleresim_perform_id', string="Performanca")
    status_vlersim = fields.Selection([('1', 'Draft'), ('2', 'Running'), ('3', 'Done')], string="Statusi")
    # arritshmeria = fields.Float(compute="_get_avg_points", string="Mesatarja e pikeve")
    #
    #
    # @api.multi
    # def _get_avg_points(self):
    #     for arritshmeri in self:
    #         arritshmeri_obj = 0.0
    #         avg_tot = 0.0
    #         if arritshmeri.performanc_ids.objektiv_id.arritshmeria_obj:
    #             for arrits_tot in arritshmeri.performanc_ids.objektiv_id:
    #              arritshmeri_obj += arrits_tot.arritshmeria_obj
    #
    #             avg_tot = arritshmeri_obj / len(arritshmeri.performanc_ids.objektiv_id)
    #         self.arritshmeria = avg_tot
    #


    # @api.constrains('status_vlersim')
    # def _check_pike_status(self):
    #     if (self.status_vlersim != '3'):
    #         raise ValidationError(_('Ju nuk mund te jepni piket dhe as te beni vleresimin total'))


    @api.constrains('performanc_ids')
    def _check_status_vleresim(self):

            if (self.performanc_ids.objektiv_id.statusi != '2'):
                raise ValidationError(_('Ju nuk mund te beni vleresim performance pasi objektivi i punonjesit nuk eshte ne status Running'))


